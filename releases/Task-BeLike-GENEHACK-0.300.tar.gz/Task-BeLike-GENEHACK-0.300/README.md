# NAME

Task::BeLike::GENEHACK - individuality via conformity

# VERSION

[![CPAN version](https://badge.fury.io/pl/Task-BeLike-GENEHACK.svg)](http://badge.fury.io/pl/Task-BeLike-GENEHACK)

# INFO

See
[https://metacpan.org/pod/Task::BeLike::GENEHACK](Task::BeLike::GENEHACK)
on MetaCPAN.

